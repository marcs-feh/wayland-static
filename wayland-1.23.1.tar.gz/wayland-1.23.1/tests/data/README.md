To re-generate the test data, run:

    ninja -C build/ gen-scanner-test
